
[
{
"type": "FeatureCollection",
"features": [
{
"type": "Feature",
"geometry": {
"type": "Point",
"coordinates": [
31.133889,
29.978889
]
},
"properties": {
"name": "La pyramide de Kheops",
"description": "",
"image": ""
}
},
{"type": "Feature",
"geometry": {
"type": "Point",
"coordinates": [
44.42753,
32.53554
]
},
"properties": {
"name": "Les jardins suspendus de Babylone",
"description": "",
"image": ""
}
},
{
"type": "Feature",
"geometry": {
"type": "Point",
"coordinates": [
21.63,
38.6378
]
},
"properties": {
"name": "La statue chryselephantine de Zeus",
"description": "",
"image": ""
}
},
{
"type": "Feature",
"geometry": {
"type": "Point",
"coordinates": [
27.3639,
37.9497
]
},
"properties": {
"name": "Le temple d\'Artemis",
"description": "",
"image": ""
}
},
{
"type": "Feature",
"geometry": {
"type": "Point",
"coordinates": [
27.42406,
37.03794
]
},
"properties": {"name": "Le tombeau de Mausole",
"description": "",
"image": ""
}
},
{
"type": "Feature",
"geometry": {
"type": "Point",
"coordinates": [
28.2278,
36.4511
]
},
"properties": {
"name": "Le colosse de Rhodes",
"description": "",
"image": ""
}
},
{
"type": "Feature",
"geometry": {
"type": "Point",
"coordinates": [
29.885,
31.2142
]
},
"properties": {
"name": "La tour de Pharos",
"description": "",
"image": ""
}
}
]
}
]
