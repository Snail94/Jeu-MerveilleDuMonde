<?php session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>Règles de Jeu </title>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- compiled Leaflet -->
<link rel="stylesheet" href="http://cdn.leafletjs.com/leaflet/v0.7.7/leaflet.css" />

<!-- affichage du navbar -->
<script>     $(function(){    $("#header").load("header.php");});

</script>

<!--Balise contenant le navbar -->
<div id="header"></div>
</head>

<body>
  <div class="jumbotron">

    <div class="container">

      <h1> Règles du Jeu Geo</h1>

      <p>Les règles du jeu sont simple !!! Cliquez le plus près possible du point demandé!!  <br></p>
      <h7> Merci de lire la question avant !!</h7>
    </div>

  </div>

</body>


</html>
